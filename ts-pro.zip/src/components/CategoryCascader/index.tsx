import React from 'react'
import { connect } from 'dva'
import { Cascader } from 'antd';
import { ConnectState, ConnectProps } from '@/models/connect';

interface Props extends ConnectProps {

}

class categoryCascader extends React.Component<Props>{
    state: any = {
        options: [],
        fieldNames: { label: 'categoryName', value: 'categoryCode', children: 'childs' },
    }

    UNSAFE_componentWillMount() {
        this.queryCategory()
    }

    change(val: Array<any>){
        console.log(val)
    }
    queryCategory() {
        const { dispatch } = this.props;
        if (dispatch) {
            dispatch({
                type: 'category/categoryTreeQuery',
                payload: {},
                callback: (res: any) => {
                    if (res.errorCode === '0000') {
                        // this.echo(res.returnObject, this.props.defaultValue)
                        let arr: any = []
                        res.returnObject.forEach((level1: any) => {
                            let obj = {
                                categoryCode: level1.categoryCode,
                                categoryName: level1.categoryName,
                                childs: []
                            }
                            level1.childs.forEach((level2: any) => {
                                level2.childs.forEach((level3: never) => {
                                    obj.childs.push(level3)
                                })
                            })
                            arr.push(obj)
                        })
                        this.setState({
                            options: arr
                        })
                    }
                }
            })
        }
    }

    render() {
        return (
            <div className="categorySelect">
                <Cascader expandTrigger="hover" options={this.state.options} fieldNames={this.state.fieldNames} onChange={this.change.bind(this)} />
            </div>
        )
    }
}

export default connect(({ }: ConnectState) => ({
}))(categoryCascader)
