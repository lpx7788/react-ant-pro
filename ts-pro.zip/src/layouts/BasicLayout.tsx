import ProLayout, {
  MenuDataItem,
  BasicLayoutProps as ProLayoutProps,
  Settings,
} from '@ant-design/pro-layout';
import React, { useEffect } from 'react';
import Link from 'umi/link';
import { Dispatch } from 'redux';
import { connect } from 'dva';
import RightContent from '@/components/GlobalHeader/RightContent';
import { ConnectState } from '@/models/connect';
import { router } from 'umi';
import logo from '../assets/img/LOGO-32.png';
import Footer from './Footer';
import Authorized from '@/utils/Authorized';
export interface BasicLayoutProps extends ProLayoutProps {
  breadcrumbNameMap: {
    [path: string]: MenuDataItem;
  };
  settings: Settings;
  dispatch: Dispatch;
  menuData: any;
}
export type BasicLayoutContext = { [K in 'location']: BasicLayoutProps[K] } & {
  breadcrumbNameMap: {
    [path: string]: MenuDataItem;
  };
};

const footerRender: BasicLayoutProps['footerRender'] = () => <Footer />;

const BasicLayout: React.FC<BasicLayoutProps> = props => {
  const { dispatch, children, settings } = props;
  useEffect(() => {
    if (dispatch) {
      if (localStorage.getItem('token')) {
        dispatch({
          type: 'login/getMenuDatas',
        });
      }
    }
  }, []);

  const handleMenuCollapse = (payload: boolean): void => {
    if (dispatch) {
      dispatch({
        type: 'global/changeLayoutCollapsed',
        payload,
      });
    }
  };

  const routeList: any = [];
  const getRouteLists = function getRouteList(arr: any) {
    arr.forEach((item: any) => {
      if (item.subMenus) {
        if (item.subMenus[0].hideInMenu) {
          routeList.push(item.path);
        } else {
          getRouteList(item.subMenus);
        }
      } else {
        if (item.hideInMenu) return;
        routeList.push(item.path);
      }
    }); // console.log('routeList--',routeList)
    return routeList;
  };

  const configroute: any = [];

  const getconfigrouteLists = function configrouteList(arr: any) {
    arr.forEach((item: any) => {
      if (item.children) {
        if (item.children[0].hideInMenu) {
          configroute.push(item.path);
        } else {
          configrouteList(item.children);
        }
      } else {
        if (item.hideInMenu) return;
        configroute.push(item.path);
      }
    }); // console.log('configroute--',configroute)

    return configroute;
  }; // 处理动态菜单

  const menuRouteDatas: any = (menuLists: MenuDataItem[]): MenuDataItem[] => {
    let { menuData } = props;
    menuData = [
      {
        path: '/home',
        name: 'home',
        icon: 'home',
        component: './home',
      },
      {
        path: '/order',
        name: '订单管理',
        icon: 'form',
        component: './order',
      },
      {
        path: '/carousel',
        name: '轮播管理',
        icon: 'form',
        component: './carousel',
      },
      {
        path: '/company',
        name: 'company',
        icon: 'windows',
        subMenus: [
          {
            path: '/company/companyJoin',
            name: 'companyJoin',
            component: './company/companyJoin',
          },
          {
            path: '/company/companyList',
            name: 'companyList',
            component: './company/companyList',
          },
          {
            path: '/company/companyList/companyDetail',
            name: 'companyDetail',
            component: './company/companyDetail',
            hideInMenu: 'true',
          },
          {
            path: '/company/companyList/companyDetail/companyEdit',
            name: 'companyEdit',
            component: './company/companyEdit',
            hideInMenu: 'true',
          },
          {
            path: '/company/companyAdd',
            name: 'companyAdd',
            component: './company/companyAdd',
            hideInMenu: false,
          },
          {
            path: '/company/companyUsers',
            name: 'companyUsers',
            component: './company/companyUsers',
          },
          {
            path: '/company/companyUsers/companyUserDetail',
            name: 'companyUserDetail',
            component: './company/companyUserDetail',
            hideInMenu: 'true',
          },
        ],
      },
      {
        createTime: 1510937819000,
        updateTime: 1544713369000,
        parentId: -1,
        id: 2,
        name: '认证管理',
        path: '/authenticate',
        icon: 'windows',
        css: 'layui-icon-set',
        url: 'javascript:;',
        sort: 1,
        type: 1,
        hidden: false,
        pathMethod: null,
        subMenus: [
          {
            id: 21,
            createTime: 1510937819000,
            updateTime: 1537356374000,
            parentId: 2,
            name: '用户管理',
            css: 'layui-icon-friends',
            url: '#!user',
            path: '/authenticate/user',
            sort: 2,
            type: 1,
            hidden: false,
            pathMethod: null,
            roleId: null,
            menuIds: null,
            subMenus: [
              {
                id: 99,
                createTime: 1510937819000,
                updateTime: 1537356374000,
                parentId: 2,
                name: '按钮1',
                css: 'layui-icon-friends',
                url: '#!user',
                path: '/authenticate/1',
                sort: 2,
                type: 1,
                hideInMenu: true,
                pathMethod: null,
                subMenus: null,
                roleId: null,
                menuIds: null,
              },
              {
                id: 96,
                createTime: 1510937819000,
                updateTime: 1537356374000,
                parentId: 2,
                name: '按钮2',
                css: 'layui-icon-friends',
                url: '#!user',
                path: '/authenticate/2',
                sort: 2,
                type: 1,
                hideInMenu: true,
                pathMethod: null,
                subMenus: null,
                roleId: null,
                menuIds: null,
              },
            ],
          },
          {
            id: 22,
            createTime: 1510937819000,
            updateTime: 1547480080000,
            parentId: 2,
            name: '角色管理',
            css: 'layui-icon-user',
            url: '#!role',
            path: '/authenticate/role',
            sort: 3,
            type: 1,
            hidden: false,
            pathMethod: null,
            subMenus: null,
            roleId: null,
            menuIds: null,
          },
          {
            id: 23,
            createTime: 1510937819000,
            updateTime: 1535941427000,
            parentId: 2,
            name: '菜单管理',
            css: 'layui-icon-menu-fill',
            url: '#!menus',
            path: '/authenticate/menu',
            sort: 4,
            type: 1,
            hidden: false,
            pathMethod: null,
            subMenus: null,
            roleId: null,
            menuIds: null,
          },
          {
            id: 24,
            createTime: 1510937819000,
            updateTime: 1535941427000,
            parentId: 2,
            name: '应用管理',
            css: 'layui-icon-menu-fill',
            url: '#!menus',
            path: '/authenticate/application',
            sort: 4,
            type: 1,
            hidden: false,
            pathMethod: null,
            subMenus: null,
            roleId: null,
            menuIds: null,
          },
          {
            id: 24,
            createTime: 1510937819000,
            updateTime: 1535941427000,
            parentId: 2,
            name: 'token管理',
            css: 'layui-icon-menu-fill',
            url: '#!menus',
            path: '/authenticate/token',
            sort: 4,
            type: 1,
            hidden: false,
            pathMethod: null,
            subMenus: null,
            roleId: null,
            menuIds: null,
          },
        ],
        roleId: null,
        menuIds: null,
      },
      {
        path: '/integral',
        name: '积分管理',
        icon: 'red-envelope',
        subMenus: [
          {
            path: '/integral/integralOrder',
            name: '积分订单',
            icon: 'red-envelope',
            component: './integral/integralOrder',
          },
          {
            path: '/integral/exchangeSet',
            name: '兑换设置',
            icon: 'red-envelope',
            component: './integral/exchangeSet',
          },
        ],
      },
    {
          path: '/hedging',
          name: '套保管理',
          icon: 'project',
          subMenus: [
            {
              path: '/hedging/hedge-account',
              name: '套保账户',
            },
            {
              path: '/hedging/front-address-management',
              name: '前置地址管理',
            },
          ],
        },
      {
        path: '/information',
        name: '资讯管理',
        icon: 'control',
        subMenus: [
          {
            path: '/information/all-information',
            name: '全部资讯',
          },
          {
            path: '/information/release-information',
            name: '发布资讯',
          },
        ],
      },
    ];
    const configRouteArrList = menuData.length != 0 ? getconfigrouteLists(menuLists) : '';
    const routeArrList = menuData.length != 0 ? getRouteLists(menuData) : [];
    const { pathname } = location;

    if (
      pathname != '/exception/404' &&
      pathname != '/exception/403' &&
      routeArrList.includes(pathname) === false
    ) {
      // 页面不存在
      if (configRouteArrList.includes(pathname) === false) {
        router.push({
          pathname: '/exception/404',
        });
      } // 无权限访问页面

      if (configRouteArrList.includes(pathname) === true) {
        router.push({
          pathname: '/exception/403',
        });
      }
    }

    const menuList = JSON.stringify(menuData).replace(/subMenus/g, 'children');
    return JSON.parse(menuList) ? JSON.parse(menuList) : [];
  };

  // const menuDataRender = (menuList: MenuDataItem[]): MenuDataItem[] =>
  //   menuList.map(item => {
  //     const localItem = { ...item, children: item.children ? menuDataRender(item.children) : [] };
  //     return Authorized.check(item.authority, localItem, null) as MenuDataItem;
  //   });

  return (
    <ProLayout
      logo={logo}
      onCollapse={handleMenuCollapse}
      menuItemRender={(menuItemProps, defaultDom) => {
        if (menuItemProps.isUrl) {
          return defaultDom;
        }

        return <Link to={menuItemProps.path}>{defaultDom}</Link>;
      }}
      breadcrumbRender={(routers = []) => [
        {
          path: '/home',
          breadcrumbName: '首页',
        },
        ...routers,
      ]}
      itemRender={(route, params, routes, paths) => {
        const first = routes.indexOf(route) === 0;
        return first ? (
          <Link to={paths.join('/')}>{route.breadcrumbName}</Link>
        ) : (
          <span>{route.breadcrumbName}</span>
        );
      }}
      footerRender={footerRender}
      menuDataRender={menuRouteDatas}
      // menuDataRender={menuDataRender}
      rightContentRender={rightProps => <RightContent {...rightProps} />}
      {...props}
      {...settings}
    >
      {children}
    </ProLayout>
  );
};

export default connect(({ global, settings, login }: ConnectState) => ({
  collapsed: global.collapsed,
  settings,
  menuData: login.menuData,
}))(BasicLayout);
