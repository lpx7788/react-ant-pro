let clientId = 'dms';
let clientSecret = 'webApp';
export default  { 
  clientId:clientId,
  clientSecret:clientSecret 
};
