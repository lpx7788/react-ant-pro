export default {
  users_exportData: '/v1.0/user/company/exportData', //用户列表导出
  companys_exportData: '/v1.0/company/exportData', //企业列表导出
  integralorder_export: '/v1.1/integralorder/exportData',
};
