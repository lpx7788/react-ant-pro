import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'D:/react-pro/ts-pro/ts-pro/src/pages/.umi/LocaleWrapper.jsx';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    component: require('../user/login').default,
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: require('../user/login').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    path: '/',
    component: require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: require('../../layouts/BasicLayout').default,
        routes: [
          {
            path: '/',
            redirect: '/home',
            exact: true,
          },
          {
            path: '/home',
            name: '平台主页',
            icon: 'home',
            component: require('../home').default,
            exact: true,
          },
          {
            path: '/company',
            name: 'company',
            icon: 'windows',
            routes: [
              {
                path: '/company/companyJoin',
                name: 'companyJoin',
                component: require('../company/companyJoin').default,
                exact: true,
              },
              {
                path: '/company/companyList',
                name: 'companyList',
                component: require('../company/companyList').default,
                exact: true,
              },
              {
                path: '/company/companyList/companyDetail',
                name: 'companyDetail',
                component: require('../company/companyDetail').default,
                hideInMenu: 'true',
                exact: true,
              },
              {
                path: '/company/companyList/companyDetail/companyEdit',
                name: 'companyEdit',
                component: require('../company/companyEdit').default,
                hideInMenu: 'true',
                exact: true,
              },
              {
                path: '/company/companyAdd',
                name: 'companyAdd',
                component: require('../company/companyAdd').default,
                hideInMenu: 'true',
                exact: true,
              },
              {
                path: '/company/companyUsers',
                name: 'companyUsers',
                component: require('../company/companyUsers').default,
                exact: true,
              },
              {
                path: '/company/companyUsers/companyUserDetail',
                name: 'companyUserDetail',
                component: require('../company/companyUserDetail').default,
                hideInMenu: 'true',
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/order',
            name: '订单管理',
            icon: 'form',
            component: require('../order').default,
            exact: true,
          },
          {
            path: '/carousel',
            name: '轮播管理',
            icon: 'form',
            component: require('../carousel').default,
            exact: true,
          },
          {
            path: '/feedback',
            name: '意见反馈',
            icon: 'smile',
            component: require('../feedback').default,
            exact: true,
          },
          {
            path: '/information',
            name: '资讯管理',
            icon: 'control',
            routes: [
              {
                path: '/information/all-information',
                name: '全部资讯',
                component: require('../information/all-information').default,
                exact: true,
              },
              {
                path: '/information/release-information',
                name: '发布资讯',
                component: require('../information/release-information')
                  .default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/hedging',
            name: '套保管理',
            icon: 'project',
            routes: [
              {
                path: '/hedging/hedge-account',
                name: '套保账户',
                component: require('../hedging/hedge-account').default,
                exact: true,
              },
              {
                path: '/hedging/front-address-management',
                name: '前置地址管理',
                component: require('../hedging/front-address-management')
                  .default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/integral',
            name: '积分管理',
            icon: 'red-envelope',
            routes: [
              {
                path: '/integral/integralOrder',
                name: '积分订单',
                icon: 'red-envelope',
                component: require('../integral/integralOrder').default,
                exact: true,
              },
              {
                path: '/integral/exchangeSet',
                name: '兑换设置',
                icon: 'red-envelope',
                component: require('../integral/exchangeSet').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/authenticate',
            name: '认证管理',
            icon: 'windows',
            routes: [
              {
                path: '/authenticate/user',
                name: '用户管理',
                component: require('../authenticate/user').default,
                exact: true,
              },
              {
                path: '/authenticate/role',
                name: '角色管理',
                component: require('../authenticate/role').default,
                exact: true,
              },
              {
                path: '/authenticate/menu',
                name: '菜单管理',
                component: require('../authenticate/menu').default,
                exact: true,
              },
              {
                path: '/authenticate/application',
                name: '应用管理',
                component: require('../authenticate/application').default,
                exact: true,
              },
              {
                path: '/authenticate/token',
                name: 'token管理',
                component: require('../authenticate/token').default,
                exact: true,
              },
              {
                path: '/authenticate/my',
                name: '我的信息',
                component: require('../authenticate/my').default,
                exact: true,
              },
              {
                component: require('../exception/403').default,
                exact: true,
              },
              {
                component: require('../exception/404').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            component: require('../exception/403').default,
            exact: true,
          },
          {
            component: require('../exception/404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: require('../exception/403').default,
        exact: true,
      },
      {
        component: require('../exception/404').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: require('../exception/403').default,
    exact: true,
  },
  {
    component: require('../exception/404').default,
    exact: true,
  },
  {
    component: () =>
      React.createElement(
        require('D:/react-pro/ts-pro/ts-pro/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
