import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'D:/react-pro/ts-pro/ts-pro/src/pages/.umi-production/LocaleWrapper.jsx';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    component: require('../user/login').default,
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: require('../user/login').default,
        exact: true,
      },
    ],
  },
  {
    path: '/',
    component: require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: require('../../layouts/BasicLayout').default,
        authority: ['admin', 'user'],
        routes: [
          {
            path: '/',
            redirect: '/home',
            exact: true,
          },
          {
            path: '/home',
            name: 'home',
            icon: 'home',
            component: require('../home').default,
            exact: true,
          },
          {
            path: '/company',
            name: 'company',
            icon: 'windows',
            routes: [
              {
                path: '/company/companyJoin',
                name: 'companyJoin',
                component: require('../company/companyJoin').default,
                exact: true,
              },
              {
                path: '/company/companyList',
                name: 'companyList',
                component: require('../company/companyList').default,
                exact: true,
              },
              {
                path: '/company/companyUsers',
                name: 'companyUsers',
                component: require('../company/companyUsers').default,
                exact: true,
              },
            ],
          },
          {
            path: '/order',
            name: 'order',
            icon: 'form',
            component: require('../order').default,
            exact: true,
          },
          {
            path: '/feedback',
            name: 'feedback',
            icon: 'smile',
            component: require('../feedback').default,
            exact: true,
          },
          {
            path: '/information',
            name: 'information',
            icon: 'project',
            routes: [
              {
                path: '/information/all-information',
                name: 'all-information',
                component: require('../information/all-information').default,
                exact: true,
              },
              {
                path: '/information/release-information',
                name: 'release-information',
                component: require('../information/release-information')
                  .default,
                exact: true,
              },
            ],
          },
          {
            component: require('../404').default,
            exact: true,
          },
        ],
      },
      {
        component: require('../404').default,
        exact: true,
      },
    ],
  },
  {
    component: require('../404').default,
    exact: true,
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
