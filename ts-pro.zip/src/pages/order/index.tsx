import React from 'react';
import { connect } from 'dva';
import styles from './style.less';
import { ConnectState, ConnectProps } from '@/models/connect';
import locale from 'antd/es/date-picker/locale/zh_CN';
import { Select, Form, Button, Radio, DatePicker, Table, Pagination, Input, Row, Col } from 'antd';
import AntdRadioGroup from '@/components/AntdRadioGroup';
import { router } from 'umi';
const { Option } = Select;
const { Search } = Input;
const { RangePicker } = DatePicker;

interface OrderProps extends ConnectProps {
  loading: boolean;
  orderList: any;
  companyList: {
    buyer: Array<any>,
    seller: Array<any>
  }
}

interface OrderState {
  parameter: any
  groupArr: Array<object>
  tableListtitle: Array<object>
  priceTypeArr: Array<object>
  deliveryType: Array<object>
  totalPage: Number,
}

class Order extends React.Component<OrderProps, OrderState> {
  state: OrderState = {
    groupArr: [
      { value: 'today', textName: '今天', key: 1 },
      { value: 'yesterday', textName: '昨天', key: 2 },
      { value: 'lastWeek', textName: '最近一周', key: 3 },
      { value: 'lastMonth', textName: '最近30天', key: 4 },
      { value: 'lastThreeMonth', textName: '最近90天', key: 5 },
      { value: 'all', textName: '累计', key: 6 },
    ],
    totalPage: 0, //总页数
    tableListtitle: [
      { title: '订单编号', dataIndex: 'customerOrderCode', align: 'center' },
      { title: '买家', dataIndex: 'buyCompanyName', align: 'center' },
      { title: '卖家', dataIndex: 'sellCompanyName', align: 'center' },
      { title: '点价人', width: 100, dataIndex: 'createUserName', align: 'center' },
      { title: '商品名称', dataIndex: 'categoryName', align: 'center' },
      { title: '合约', dataIndex: 'contractName', align: 'center' },
      { title: '基价', dataIndex: 'basePrice', align: 'center' },
      { title: '成交数量', dataIndex: 'dealQuantity', align: 'center' },
      { title: '下单数量', dataIndex: 'quantity', align: 'center' },
      { title: '订单状态', align: 'center', render: (record: any) => record.orderStatus === 2 || record.orderStatus === 5 ? '111' : record.orderStatusName },
      { title: '下单时间', dataIndex: 'createDate', align: 'center' },
      {
        title: '操作', width: 100, render: (row: any) =>
          <Button type="primary" size="small" shape="round" onClick={this.goToCompanyDetail.bind(this, row)} icon="eye">查看</Button>, align: 'center'
      },
    ],
    priceTypeArr: [
      { value: '1', textName: '点价', key: 1 },
      { value: '3', textName: '延期点价', key: 3 },
      { value: '2', textName: '确定价', key: 2 },
    ],
    deliveryType: [
      { value: '1', textName: '现货商城', key: 1 },
      { value: '2', textName: '求购大厅', key: 2 },

    ],
    parameter: {
      buyUserCompanyCode: "",
      createDateEnd: null,
      createDateStart: null,
      dateKey: "today",
      dateNum: 0,
      deliveryType: "1",
      orderStatus: "",
      pageNum: 1,
      pageSize: 20,
      priceType: "1",
      queryKey: "",
      sellUserCompanyCode: "",
    },
  };

  UNSAFE_componentWillMount() {
    this.getPageDatas()
  }
  //跳转详情页
  goToCompanyDetail(row: any) {
    router.push({ pathname: '/Application/ApplicationDetail', query: { orderCode: row.orderCode } })
  }
  getPageDatas() {
    const { dispatch } = this.props;
    if (dispatch) {
      dispatch({
        type: 'order/fetchOrderListDatas',
        payload: this.state.parameter
      })
      dispatch({
        type: 'order/fetchCompanyList',
        payload: { type: 1 }
      })
    }
  }

  //修改日期
  handleTImeChange = (e: String) => {
    let parameter = this.state.parameter
    parameter['dateKey'] = e
    parameter['createDateStart'] = ''
    parameter['createDateEnd'] = ''
    this.setState({
      parameter: parameter
    });
    this.getPageDatas();
  };

  //获取时间戳
  handelRangePicker(date: object, dateStrings: [string, string]) {
    let parameter = this.state.parameter
    parameter['dateKey'] = ''
    parameter['createDateStart'] = new Date(dateStrings[0]).getTime()
    parameter['createDateEnd'] = new Date(dateStrings[1]).getTime()
    this.handleParameter(parameter)
  }


  // setState参数值
  handleParameter(parameter: any) {
    this.setState({
      parameter: parameter,
    });
    this.getPageDatas();
  }

  // 刷新
  handelRefresh() {
    let parameter = this.state.parameter
    parameter['dateKey'] = 'today'
    parameter['createDateStart'] = ''
    parameter['createDateEnd'] = ''
    this.handleParameter(parameter)
  }
  //搜索
  handleSearch(val: string) {
    this.handleparmas(val, 'dateKey')
  }
  //分页
  onPageChange = (e: Number) => {
    this.handleparmas(e, 'dateKey')
  };

  handleOrderStatus = (e: any) => {
    this.handleparmas(e.target.value, 'orderStatus')
  };


  handleparmas(value: any, dataName: string) {
    let parameter = this.state.parameter;
    parameter[dataName] = value;
    this.setState({
      parameter: parameter,
    });
    this.getPageDatas();
  }

  //修改订单来源
  handleType = (e: string, type: string) => {
    this.handleparmas(e, type)
  };

  handelexport = (e: string,val: string) => {
  }

  render() {
    return (
      <div className={styles.homePageContent}>
        <header className="pageHeader">
          <Row >
            <Col className="gutter-row mT20" >
              <AntdRadioGroup value={this.state.parameter.dateKey} groupArr={this.state.groupArr} change={this.handleTImeChange} />
              <RangePicker className={`mL20`} onChange={this.handelRangePicker.bind(this)} locale={locale} />
            </Col>
          </Row>
          <Row>
              <Col className="gutter-row mT20">
              <Search className={`${styles.search}`} placeholder="请输入用户/手机号码" onSearch={value => this.handleSearch(value)} enterButton />
                <Button icon="download" className={`mL20`} type="primary" onClick={(e: any) => { this.handelexport(e,"11") }}  >导出</Button>
                <Button icon="sync" className={`mL20`} type="primary" onClick={this.handelRefresh.bind(this)}>刷新</Button>
              </Col>
          </Row>
          <Row >
            <Col className="gutter-row mT20" >
              <Form>
                <Form.Item label="订单来源：" labelCol={{ span: 1 }}>
                  <AntdRadioGroup value={this.state.parameter.deliveryType} groupArr={this.state.deliveryType} change={(e: any) => { this.handleType(e, "deliveryType") }} />
                </Form.Item>

                <Form.Item label="作价方式：" labelCol={{ span: 1 }}>
                  <AntdRadioGroup value={this.state.parameter.priceType} groupArr={this.state.priceTypeArr} change={(e: any) => { this.handleType(e, "priceType") }} />
                </Form.Item>
                <Form.Item label="买家公司：" labelCol={{ span: 1 }}>
                  <Select
                    showSearch
                    style={{ width: 320 }}
                    placeholder="请选择或者输入买家公司"
                    optionFilterProp="children"
                  >
                    {
                      this.props.companyList.buyer ?
                        this.props.companyList.buyer.map(item => (
                          <Option key={item.companyCode} value={item.companyName}>{item.companyName}</Option>
                        )) : ''
                    }
                  </Select>
                </Form.Item>

                <Form.Item label="卖家公司：" labelCol={{ span: 1 }}>
                  <Select
                    showSearch
                    style={{ width: 320 }}
                    placeholder="请选择或者输入卖家公司"
                    optionFilterProp="children"
                  >
                    {
                      this.props.companyList.seller ?
                        this.props.companyList.seller.map(item => (
                          <Option key={item.companyCode} value={item.companyName}>{item.companyName}</Option>
                        )) : ''
                    }
                  </Select>
                </Form.Item>

                <Form.Item label="订单状态：" labelCol={{ span: 1 }}>
                  <Radio.Group value={this.state.parameter.orderStatus} onChange={this.handleOrderStatus}
                  >
                    <Radio.Button value="">全部</Radio.Button>
                    <Radio.Button value="1">待确认</Radio.Button>
                    <Radio.Button value="4" className={`${this.state.parameter.priceType === '1' ? 'inline-block' : 'hidden'}`}  >已挂单</Radio.Button>
                    <Radio.Button value={this.state.parameter.priceType === '2' ? '2' : '5'}>待生成合同</Radio.Button>
                    <Radio.Button value="6">已生成合同</Radio.Button>
                    <Radio.Button value="3">已取消</Radio.Button>
                  </Radio.Group>
                </Form.Item>
              </Form>
            </Col>
          </Row>
        </header>
        <div className={`mT20 ${styles.pageContent}`}>
          <Table<any>
            loading={this.props.loading}
            size="middle"
            pagination={false}
            rowKey={record => record.index}
            bordered
            columns={this.state.tableListtitle}
            dataSource={this.props.orderList.list ? this.props.orderList.list : []}
          />
          <section className={`m20 ${styles.paginationBtn} ${this.state.totalPage !== 0 ? 'show' : 'hidden'}`}>
            {/* <Pagination
              size="small"
              total={this.state.totalPage}
              onChange={this.onPageChange}
              showSizeChanger={true}
            /> */}
          </section>
        </div>
      </div>
    );
  }
}

export default connect(({ order, loading }: ConnectState) => ({
  orderList: order.orderList,
  companyList: order.companyList,
  loading: loading.models.order,
}))(Order);
