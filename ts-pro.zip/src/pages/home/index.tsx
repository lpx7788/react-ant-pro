import React from 'react';
import { connect } from 'dva';
import styles from './style.less';
import { ConnectState, ConnectProps } from '@/models/connect';
import { Card, DatePicker,Button} from 'antd';
import AntdRadioGroup from '@/components/AntdRadioGroup';
const { RangePicker } = DatePicker;
import env from '../../../config/env';

interface HomeProps extends ConnectProps {
  loading: boolean;
  HomeDataList:Array<any>;
}

interface HomeState {
  parameter: {
    dateKey: any,
    createDateStart: any,
    createDateEnd: any
  }
  groupArr:  Array<object> 
}

class Home extends React.Component<HomeProps, HomeState> {
  state: HomeState = {
    groupArr: [
      { value: 'today', textName: '今天', key: 1 },
      { value: 'yesterday', textName: '昨天', key: 2 },
      { value: 'lastWeek', textName: '最近一周', key: 3 },
      { value: 'lastMonth', textName: '最近30天', key: 4 },
      { value: 'lastThreeMonth', textName: '最近90天', key: 5 },
      { value: 'all', textName: '累计', key: 6 },
    ],
    parameter: {
      dateKey: 'today',
      createDateStart: '',
      createDateEnd: ''
    },
  };

  UNSAFE_componentWillMount() {

    this.getPageDatas()
   
  }

  getPageDatas() {
    const { dispatch } = this.props;

    if (dispatch) {
      dispatch({
        type: 'login/getuserDatas',
      });
      dispatch({
        type: 'home/fetchDatas',
        payload: this.state.parameter
      })
    }
  }

  //修改日期
  handleTImeChange = (e: String) => {
    let parameter = this.state.parameter
    parameter['dateKey'] = e
    parameter['createDateStart'] =''
    parameter['createDateEnd'] =''
    this.setState({
      parameter: parameter
    });
    this.getPageDatas();
  };

  //获取时间戳
  handelRangePicker(date: object, dateStrings: [string, string]) {
    let parameter = this.state.parameter
    parameter['dateKey'] = ''
    parameter['createDateStart'] =new Date(dateStrings[0]).getTime()
    parameter['createDateEnd'] =new Date(dateStrings[1]).getTime()
    this.setState({
      parameter: parameter
    });
    this.getPageDatas();
  }

  // 刷新
  handelRefresh(){
    let parameter = this.state.parameter
    parameter['dateKey'] = 'today'
    parameter['createDateStart'] =''
    parameter['createDateEnd'] =''
    this.setState({
      parameter: parameter
    });
  }

  render() {
    // console.log(this.props.HomeDataList)
    return (
      <div className={styles.homePageContent}>
        <header className="pageHeader">
          <AntdRadioGroup value={this.state.parameter.dateKey} groupArr={this.state.groupArr} change={this.handleTImeChange} />
          <RangePicker className={` ${styles.homePageContent}`} onChange={this.handelRangePicker.bind(this)} placeholder={['开始日期', '结束日期']} />
          <Button type="primary" icon="sync" onClick={this.handelRefresh.bind(this)}>刷新</Button>
        </header>
        <div className="pageContent">
          <div className={`border ${styles.contentItem}`}>
            <p className={styles.contentTitle}>基本数据</p>
            <section>
              {this.props.HomeDataList?
                this.props.HomeDataList.map((item, index) => {
                  return (
                    <div className={`border ${styles.cardListItem}`} key={index} style={{ width: 240 }}>
                      <Card title={item.common} bordered={false}>
                        <p className={`fontW500  ${styles.number}`}>{item.count}</p>
                        <p className={`fontW500 red ${styles.persen}`}>{item.percentage}</p>
                      </Card>
                    </div>
                  );
                }) : ''}
            </section>
          </div>
        </div>
      </div>
    );
  }
}

export default connect(({ home, loading }: ConnectState) => ({
  HomeDataList: home.HomeDataList,
  loading: loading.models.home,
}))(Home);
