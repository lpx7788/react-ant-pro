import React from 'react';
import { connect } from 'dva';
import styles from './style.less';
import { ConnectState, ConnectProps } from '@/models/connect';
import { Button,Table,message ,Popconfirm} from 'antd';

interface OrderProps extends ConnectProps {
  loading: boolean;
  carouselList:any
  mobileCarouselList:any
}

interface OrderState {
  mobileTableListTitle: Array<object>
}

class Order extends React.Component<OrderProps, OrderState> {
  state: OrderState = {
    mobileTableListTitle: [
      { title: '排序', dataIndex: 'sortId', align: 'center' },
      { title: '轮播标题', dataIndex: 'title', align: 'center' },
      { title: '跳转连接', dataIndex: 'outLinkUrl', align: 'center' },
      { title: '更新时间', dataIndex: 'lastupdateDate', align: 'center' },
      {
        title: '操作', align: 'center',width:200, render: (row: any) =>
        <div>
          <Button className="m5 bgGreen" onClick={this.handelEdit.bind(this,row)}  icon="edit" shape="circle"></Button> 
          <Popconfirm placement="top" title={'确定移动该轮播?'}  onConfirm={this.handleMove.bind(this,row,'1')} okText="确定" cancelText="取消">
            <Button className="m5 bgBlueSky"   icon="vertical-align-top" shape="circle"></Button> 
          </Popconfirm> 
          <Popconfirm placement="top" title={'确定移动该轮播?'}  onConfirm={this.handleMove.bind(this,row,'2')} okText="确定" cancelText="取消">
            <Button className="m5 bgBlueSky"   icon="vertical-align-bottom" shape="circle"></Button> 
          </Popconfirm> 
          <Popconfirm placement="top" title={'确定要删除吗?'} onConfirm={this.handleDelete.bind(this,row)} okText="确定" cancelText="取消">
            <Button className="m5" type="danger" icon="delete" shape="circle"></Button> 
          </Popconfirm>  
        </div>
      }
    ],
  };
  handelEdit(){

  }
  
  // 新增
  handelAdd(){
    let self =this;
    let {dispatch} = this.props
    if(dispatch){
      dispatch({
        type:'carousel/addCarouselRequest',
        payload:{
          title: '',
          type:'',
          outLinkUrl: '',
          coverPicFile: '',
          coverPicUrl: '',
          coverPicType: '',
        },
        callback:(res:any)=>{
          if(res.errorCode==='0000'){
            message.success('操作成功');
            self.getPageDatas()
          }
        }
      })
    }
  }

  // 移动
  handleMove(row:any,type:any){
    let self =this;
    let {dispatch} = this.props
    if(dispatch){
      dispatch({
        type:'carousel/moveCarouselRequest',
        payload:{
          id:row.id,
          move:type
        },
        callback:(res:any)=>{
          if(res.errorCode==='0000'){
            message.success('操作成功');
            self.getPageDatas()
          }
        }
      })
    }
  }

  //删除
  handleDelete(row:any){
    let self =this;
    let {dispatch} = this.props
    if(dispatch){
      dispatch({
        type:'carousel/deleteCarouselRequest',
        payload:{id:row.id},
        callback:(res:any)=>{
          if(res.errorCode==='0000'){
            message.success('操作成功');
            self.getPageDatas()
          }
        }
      })
    }
  }
  
  UNSAFE_componentWillMount() {
    this.getPageDatas()
  }

  getPageDatas() {
    const { dispatch } = this.props;
    if (dispatch) {
      dispatch({
        type: 'carousel/carouselListRequest',
        payload: { type: 1 }
      })
      dispatch({
        type: 'carousel/carouselListRequest',
        payload: { type: 2}
      })
    }
  }

  render() {
    return (
      <div className={styles.homePageContent}>
         <Button type="primary" onClick={this.handelAdd.bind(this)}>新建轮播</Button>
        <div className={`mT20 ${styles.pageContent}`}>
          <div>
            <h3>手机端轮播</h3>
            <Table<any>
              size="middle"
              loading={this.props.loading}
              pagination={false}
              rowKey={record => record.id}
              bordered
              columns={this.state.mobileTableListTitle}
              dataSource={this.props.carouselList? this.props.carouselList.returnObject: []} />
          </div>
          <div className="mT20">
            <h3>网页端轮播</h3>
            <Table<any>
              size="middle"
              loading={this.props.loading}
              pagination={false}
              rowKey={record => record.id}
              bordered
              columns={this.state.mobileTableListTitle}
              dataSource={this.props.mobileCarouselList ? this.props.mobileCarouselList.returnObject : []} />
          </div>
        </div>
      </div>
    );
  }
}

export default connect(({ carousel, loading }: ConnectState) => ({
  carouselList: carousel.carouselList,
  mobileCarouselList: carousel.mobileCarouselList,
  loading: loading.models.carousel,
}))(Order);
