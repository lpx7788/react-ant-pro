import { Effect } from 'dva';
import { Reducer } from 'redux';
import {
  queryIntegralList,
  addRewardIntegral,
  deleteIntegral,
  queryIntegralOrderList,
  updateIntegralOrder,
  refuseIntegralOrder,
  queryCashingCommodityList,
  deleteCashingCommodity,
  joinCashingCommodity,
} from '@/services/integral';

export interface IntegralModelState {
  integralList?: Array<Object>;
  integralOrders?: Array<Object>;
  exchangeSetList: Array<Object>;
}

export interface IntegralModelType {
  namespace: 'integral';
  state: IntegralModelState;
  effects: {
    queryIntegralList: Effect;
    addRewardIntegral: Effect;
    deleteIntegral: Effect;
    queryIntegralOrderList: Effect;
    updateIntegralOrder: Effect;
    refuseIntegralOrder: Effect;
    queryCashingCommodityList: Effect;
    deleteCashingCommodity: Effect;
    joinCashingCommodity: Effect;
  };
  reducers: {
    queryIntegralList_cb: Reducer<IntegralModelState>;
    queryIntegralOrderList_cb: Reducer<IntegralModelState>;
    queryCashingCommodityList_cb: Reducer<IntegralModelState>;
  };
}

const IntegralModel: IntegralModelType = {
  namespace: 'integral',
  state: {
    integralList: [],
    integralOrders: [],
  },

  effects: {
    *queryIntegralList(_, { call, put }) {
      const response = yield call(queryIntegralList, _.payload);
      if (response) {
        yield put({
          type: 'queryIntegralList_cb',
          payload: response,
        });
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *addRewardIntegral(_, { call, put }) {
      const response = yield call(addRewardIntegral, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *deleteIntegral(_, { call, put }) {
      const response = yield call(deleteIntegral, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *queryIntegralOrderList(_, { call, put }) {
      const response = yield call(queryIntegralOrderList, _.payload);
      if (response) {
        yield put({
          type: 'queryIntegralOrderList_cb',
          payload: response,
        });
      }
    },
    *refuseIntegralOrder(_, { call, put }) {
      const response = yield call(refuseIntegralOrder, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *updateIntegralOrder(_, { call, put }) {
      const response = yield call(updateIntegralOrder, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *queryCashingCommodityList(_, { call, put }){
      const response = yield call(queryCashingCommodityList, _.payload);
      if (response) {
        yield put({
          type: 'queryCashingCommodityList_cb',
          payload: response,
        });
      }
    },
    *deleteCashingCommodity(_, { call, put }){
      const response = yield call(deleteCashingCommodity, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
    *joinCashingCommodity(_, { call, put }){
      const response = yield call(joinCashingCommodity, _.payload);
      if (response) {
        if (_.callback && typeof _.callback === 'function') {
          _.callback(response);
        }
      }
    },
  },

  reducers: {
    queryIntegralList_cb(state, action) {
      return {
        ...state,
      };
    },
    queryIntegralOrderList_cb(state, action) {
      return {
        ...state,
        integralOrders: action.payload,
      };
    },
    queryCashingCommodityList_cb(state, action) {
      return {
        ...state,
        exchangeSetList: action.payload.returnObject,
      };
    },
  },
};

export default IntegralModel;
